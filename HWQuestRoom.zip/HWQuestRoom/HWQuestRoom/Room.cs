﻿namespace HWQuestRoom
{
    public class Room
    {
        public string? Id { get; set; }
        public string? Title { get; set; }
        public string? RoomPath { get; set; }
    }
}
