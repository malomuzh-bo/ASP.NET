﻿namespace HW111
{
    public class Country
    {
        public string Title { get; set; }
        public string Capital { get; set; }
    }
}
