﻿namespace HW111
{
    public class Restaurant
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string City { get; set; }

    }
}
